/* contrib/pg_enterprise_views/pg_enterprise_views--1.0.sql */
-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "create extension pg_enterprise_views" to load this file. \quit

-- We should notice user to install this into postgres db
\echo "[pg_enterprise_views] is installing... Please ensure the installation database is: postgres"

/********************************************************************
 * SCHEMA & USER PEV
 ********************************************************************/
CREATE SCHEMA IF NOT EXISTS pev;
CREATE USER pev WITH PASSWORD 'pev';
CREATE SEQUENCE PEV.SEQ_PEV_SNAP_ID
                INCREMENT BY 1
                MINVALUE 1
                NO MAXVALUE
                START 1
                CYCLE;



CREATE FUNCTION pev.pev_register_info(OUT register_info text)
RETURNS text AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;
GRANT EXECUTE ON FUNCTION PEV.pev_register_info() TO PUBLIC;

CREATE FUNCTION pev.pev_register(IN active_code text, OUT tips text)
RETURNS text AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;
GRANT EXECUTE ON FUNCTION PEV.pev_register(active_code text, OUT tips text) TO PUBLIC;

/********************************************************************
 * VIEW & TABLE PEV.PEV_SQL_STATS
 ********************************************************************/
CREATE FUNCTION PEV.PEV_SQL_STATS
(
   OUT userid oid,
   OUT dbid oid,
   OUT queryid bigint,
   OUT query text,
   OUT calls int8,
   OUT total_time float8,
   OUT min_time float8,
   OUT max_time float8,
   OUT mean_time float8,
   OUT stddev_time float8,
   OUT rows int8,
   OUT shared_blks_hit int8,
   OUT shared_blks_read int8,
   OUT shared_blks_dirtied int8,
   OUT shared_blks_written int8,
   OUT local_blks_hit int8,
   OUT local_blks_read int8,
   OUT local_blks_dirtied int8,
   OUT local_blks_written int8,
   OUT temp_blks_read int8,
   OUT temp_blks_written int8,
   OUT blk_read_time float8,
   OUT blk_write_time float8
)
    RETURNS SETOF record
AS 'MODULE_PATHNAME'
LANGUAGE C;
GRANT EXECUTE ON FUNCTION PEV.PEV_SQL_STATS() TO PUBLIC;
CREATE VIEW PEV.PEV_SQL_STATS AS
(
    SELECT userid,
           dbid,
           queryid,
           calls,
           round(total_time :: NUMERIC, 2) as total_time_ms,
           round(min_time :: NUMERIC, 2) as min_time_ms,
           round(max_time :: NUMERIC, 2) as max_time_ms,
           round(mean_time :: NUMERIC, 2) as mean_time_ms,
           round(stddev_time :: NUMERIC, 2) as stddev_time_ms,
           rows,
           shared_blks_hit,
           shared_blks_read,
           shared_blks_dirtied,
           shared_blks_written,
           local_blks_hit,
           local_blks_read,
           local_blks_dirtied,
           local_blks_written,
           temp_blks_read,
           temp_blks_written,
           round(blk_read_time :: NUMERIC, 2) as blk_read_time_ms,
           round(blk_write_time :: NUMERIC, 2) as blk_write_time_ms
    FROM PEV.PEV_SQL_STATS()
);
GRANT SELECT ON PEV.PEV_SQL_STATS TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_SQL_STATS_HIS
(
    SNAP_ID               BIGINT,
    SAMPLE_TIME           TIMESTAMP,
    userid                oid,
    dbid                  oid,
    queryid               bigint,
    calls                 int8,
    total_time_ms         float8,
    min_time_ms           float8,
    max_time_ms           float8,
    mean_time_ms          float8,
    stddev_time_ms        float8,
    rows                  int8,
    shared_blks_hit       int8,
    shared_blks_read      int8,
    shared_blks_dirtied   int8,
    shared_blks_written   int8,
    local_blks_hit        int8,
    local_blks_read       int8,
    local_blks_dirtied    int8,
    local_blks_written    int8,
    temp_blks_read        int8,
    temp_blks_written     int8,
    blk_read_time_ms      float8,
    blk_write_time_ms     float8,
    calls_delta                 int8,
    total_time_ms_delta         float8,
    min_time_ms_delta           float8,
    max_time_ms_delta           float8,
    mean_time_ms_delta          float8,
    stddev_time_ms_delta        float8,
    rows_delta                  int8,
    shared_blks_hit_delta       int8,
    shared_blks_read_delta      int8,
    shared_blks_dirtied_delta   int8,
    shared_blks_written_delta   int8,
    local_blks_hit_delta        int8,
    local_blks_read_delta       int8,
    local_blks_dirtied_delta    int8,
    local_blks_written_delta    int8,
    temp_blks_read_delta        int8,
    temp_blks_written_delta     int8,
    blk_read_time_ms_delta      float8,
    blk_write_time_ms_delta     float8
);
CREATE INDEX IDX_PEV_SQL_STATS_HISTORY_SNAP_ID ON PEV.PEV_SQL_STATS_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_SQL_STATS_HISTORY_SAMPLE_TIME ON PEV.PEV_SQL_STATS_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_SQL
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_SQL
(
    QUERYID               BIGINT,
    DBID                  INT,
    QUERY                 TEXT,
    IFTEMP                BOOL
);
CREATE INDEX IDX_PEV_SQL_QUERYID_DBID ON PEV.PEV_SQL(QUERYID, DBID);
/********************************************************************
 * TABLE PEV.PEV_SQL_PLAN
 ********************************************************************/
CREATE FUNCTION PEV.PEV_SQL_PLAN
(
    OUT QUERYID BIGINT,
    OUT PLANID  BIGINT,
    OUT PLAN    TEXT
)
    RETURNS SETOF record
AS 'MODULE_PATHNAME'
LANGUAGE C;
GRANT EXECUTE ON FUNCTION PEV.PEV_SQL_PLAN() TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_SQL_PLAN
(
    QUERYID               BIGINT,
    PLANID                BIGINT,
    PLAN                  TEXT
);
CREATE INDEX IDX_PEV_SQL_PLAN_PLANID ON PEV.PEV_SQL_PLAN(PLANID);
/********************************************************************
 * VIEW & TABLE PEV.PEV_ACTIVE_SESSION
 ********************************************************************/
CREATE FUNCTION PEV.PEV_ACTIVE_SESSION(
    OUT datid           oid,
    OUT pid             int4,
    OUT usesysid          oid,
    OUT appname         text,
    OUT state           text,
    OUT queryId         int8,
    OUT wait_event_type text,
    OUT wait_event      text,
    OUT xact_start      timestamptz,
    OUT query_start     timestamptz,
    OUT backend_start   timestamptz,
    OUT state_change    timestamptz,
    OUT client_addr     inet,
    OUT client_hostname text,
    OUT client_port     int8,
    OUT backend_xid     xid,
    OUT backend_xmin    xid,
    OUT backend_type    text,
    OUT ssl             bool,
    OUT sslversion      text,
    OUT sslcipher       text,
    OUT sslbits         int8,
    OUT sslcompression  bool,
    OUT sslclientdn     text,
    OUT planId          int8,
    OUT query           text
)
    RETURNS SETOF record
AS 'MODULE_PATHNAME'
LANGUAGE C;
GRANT EXECUTE ON FUNCTION PEV.PEV_ACTIVE_SESSION() TO PUBLIC;
CREATE VIEW PEV.PEV_ACTIVE_SESSION AS
(
SELECT s.datid,
       d.datname,
       s.pid,
       s.usesysid,
       s.appname as application_name,
       s.backend_type,
       s.backend_start,
       s.state,
       s.state_change,
       s.backend_xid,
       s.backend_xmin,
       s.queryId,
       s.planId,
       s.query,
       s.query_start,
       s.xact_start,
       s.wait_event_type,
       s.wait_event,
       s.client_addr,
       s.client_port,
       s.client_hostname,
       s.ssl,
       s.sslcompression,
       s.sslversion,
       s.sslcipher,
       s.sslbits,
       s.sslclientdn
FROM ((PEV.PEV_ACTIVE_SESSION() s
    LEFT JOIN pg_database d ON ((s.datid = d.oid)))));
GRANT SELECT ON PEV.PEV_ACTIVE_SESSION TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_ACTIVE_SESSION_HIS
(
    SNAP_ID                     BIGINT,
    SAMPLE_TIME                 TIMESTAMP,
    datid                       OID,
    datname                     VARCHAR(2000),
    pid                         INT4,
    usesysid                    OID,
    application_name            VARCHAR(2000),
    client_addr                 VARCHAR(2000),
    client_hostname             VARCHAR(2000),
    client_port                 INT4,
    backend_type                VARCHAR(2000),
    backend_start               TIMESTAMPTZ,
    backend_xid                 XID,
    backend_xmin                XID,
    xact_start                  TIMESTAMPTZ,
    query_start                 TIMESTAMPTZ,
    queryid                     bigint,
    planId                      bigint,
    state                       VARCHAR(2000),
    state_change                TIMESTAMPTZ,
    wait_event_type             VARCHAR(2000),
    wait_event                  VARCHAR(2000),
    ssl                         bool,
    sslcompression              bool,
    sslversion                  text,
    sslcipher                   text,
    sslbits                     int8,
    sslclientdn                 text
);
CREATE INDEX IDX_PEV_ACTIVE_SESSION_HIS_SAMPLE_TIME ON PEV.PEV_ACTIVE_SESSION_HIS(SAMPLE_TIME);
/********************************************************************
 * VIEW & TABLE PEV.PEV_WAIT_EVENTS
 ********************************************************************/
CREATE VIEW PEV.PEV_WAIT_EVENTS AS
(
    SELECT *
    FROM(
            SELECT WAIT_EVENT_TYPE,
                   WAIT_EVENT,
                   COUNT(*) AS WAIT_COUNT,
                   SUM(ABS(COALESCE(EXTRACT(EPOCH FROM (NOW() - STATE_CHANGE)) * 1000, 0))::INT8) AS DURA_MS
            FROM   PG_STAT_ACTIVITY
            WHERE  WAIT_EVENT_TYPE IS NOT NULL
            AND    WAIT_EVENT IS NOT NULL
            GROUP BY WAIT_EVENT_TYPE, WAIT_EVENT
        ) A
    WHERE A.DURA_MS <> 0
    ORDER BY 4 DESC, 3 DESC, 1 ASC, 2 ASC
);
GRANT SELECT ON PEV.PEV_WAIT_EVENTS TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_WAIT_EVENTS_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    WAIT_EVENT_TYPE          VARCHAR(2000),
    WAIT_EVENT               VARCHAR(2000),
    WAIT_COUNT               INT4,
    DURA_MS                  INT8,
    DURA_MS_DELTA            INT8
);
CREATE INDEX IDX_PEV_WAIT_EVENTS_HIS_SNAP_ID ON PEV.PEV_WAIT_EVENTS_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_WAIT_EVENTS_HIS_SAMPLE_TIME ON PEV.PEV_WAIT_EVENTS_HIS(SAMPLE_TIME);
/********************************************************************
 * VIEW & TABLE PEV.PEV_LONG_TRXS
 ********************************************************************/

CREATE VIEW PEV.PEV_LONG_TRXS AS
(
    SELECT DATNAME,
           PID,
           usesysid,
           APPLICATION_NAME,
           CLIENT_ADDR,
           CLIENT_PORT,
           BACKEND_START :: TIMESTAMP AS BACKEND_START,
           STATE,
           XACT_START :: TIMESTAMP AS XACT_START,
           QUERY_START :: TIMESTAMP AS QUERY_START,
           (EXTRACT(EPOCH FROM (now() - STATE_CHANGE)) * 1000) :: int8 AS STATE_DURA_MS,
           (EXTRACT(EPOCH FROM (now() - XACT_START)) * 1000) :: int8 AS TRX_DURA_MS,
           (EXTRACT(EPOCH FROM (now() - QUERY_START)) * 1000) :: int8 AS QUERY_DURA_MS,
           WAIT_EVENT_TYPE,
           WAIT_EVENT,
           QUERYID,
           PLANID
    FROM PEV.PEV_ACTIVE_SESSION
    WHERE XACT_START < NOW() - INTERVAL '20 SECOND'
);
GRANT SELECT ON PEV.PEV_LONG_TRXS TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_LONG_TRXS_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    DATNAME                  VARCHAR(2000),
    PID                      INT4,
    USESYSID                 OID,
    APPLICATION_NAME         VARCHAR(2000),
    CLIENT_ADDR              VARCHAR(2000),
    CLIENT_PORT              INT4,
    BACKEND_START            TIMESTAMP,
    STATE                    VARCHAR(2000),
    XACT_START               TIMESTAMP,
    QUERY_START              TIMESTAMP,
    STATE_DURA_MS            BIGINT,
    TRX_DURA_MS              BIGINT,
    QUERY_DURA_MS            BIGINT,
    WAIT_EVENT_TYPE          VARCHAR(2000),
    WAIT_EVENT               VARCHAR(2000),
    QUERYID                  BIGINT,
    PLANID                   BIGINT
);
CREATE INDEX IDX_PEV_LONG_TRXS_HIS_SAMPLE_TIME ON PEV.PEV_LONG_TRXS_HIS(SAMPLE_TIME);
/********************************************************************
 * VIEW & TABLE PEV.PEV_LONG_LOCKS
 ********************************************************************/
CREATE VIEW PEV.PEV_LONG_LOCKS AS
(
    SELECT LOCK2.PID AS BLOCKER_PID,
           (SELECT ROLNAME FROM PG_CATALOG.PG_AUTHID WHERE OID = STAT2.USESYSID) AS BLOCKER_USER,
           STAT2.CLIENT_ADDR || ':' || STAT2.CLIENT_PORT AS BLOCKER_CLIENT,
           STAT2.QUERYID AS BLOCKER_QUERYID,
           STAT2.PLANID AS BLOCKER_PLANID,
           STAT2.STATE AS BLOCKER_STATE,
           LOCK1.PID AS BLOCKED_PID,
           (SELECT ROLNAME FROM PG_CATALOG.PG_AUTHID WHERE OID = STAT1.USESYSID) AS BLOCKED_USER,
           STAT1.CLIENT_ADDR || ':' || STAT1.CLIENT_PORT AS BLOCKED_CLIENT,
           STAT1.QUERYID AS BLOCKED_QUERYID,
           STAT1.PLANID AS BLOCKED_PLANID,
           STAT1.STATE AS BLOCKED_STATE,
           (EXTRACT(EPOCH FROM (NOW() - STAT1.QUERY_START))) :: INT8 AS BLOCKED_DURA_SEC,
           LOCK1.LOCKTYPE AS LOCK_TYPE,
           (SELECT DATNAME  FROM PG_CATALOG.PG_DATABASE WHERE OID = LOCK1.DATABASE) AS LOCK_DB,
           LOCK1.RELATION :: REGCLASS AS LOCK_TABLE,
           LOCK1.TUPLE AS LOCK_ROW_NUM
    FROM PG_CATALOG.PG_LOCKS LOCK1
        JOIN PEV.PEV_ACTIVE_SESSION STAT1 ON LOCK1.PID = STAT1.PID
        JOIN PG_CATALOG.PG_LOCKS LOCK2 ON (
        LOCK1.LOCKTYPE,
        LOCK1.DATABASE,
        LOCK1.RELATION,
        LOCK1.PAGE,
        LOCK1.TUPLE,
        LOCK1.VIRTUALXID,
        LOCK1.TRANSACTIONID,
        LOCK1.CLASSID,
        LOCK1.OBJID,
        LOCK1.OBJSUBID) IS NOT DISTINCT
    FROM(
        LOCK2.LOCKTYPE,
        LOCK2.DATABASE,
        LOCK2.RELATION,
        LOCK2.PAGE,
        LOCK2.TUPLE,
        LOCK2.VIRTUALXID,
        LOCK2.TRANSACTIONID,
        LOCK2.CLASSID,
        LOCK2.OBJID,
        LOCK2.OBJSUBID)
        JOIN PEV.PEV_ACTIVE_SESSION STAT2 ON LOCK2.PID = STAT2.PID
    WHERE NOT LOCK1.GRANTED  AND LOCK2.GRANTED
      AND STAT1.QUERY_START < NOW() - INTERVAL '20 SECOND'
);
GRANT SELECT ON PEV.PEV_LONG_LOCKS TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_LONG_LOCKS_HIS
(
    SNAP_ID                            BIGINT,
    SAMPLE_TIME                        TIMESTAMP,
    BLOCKER_PID                        INT4,
    BLOCKER_USER                       VARCHAR(2000),
    BLOCKER_CLIENT                     VARCHAR(2000),
    BLOCKER_QUERYID                    BIGINT,
    BLOCKER_PLANID                     BIGINT,
    BLOCKED_PID                        INT4,
    BLOCKED_USER                       VARCHAR(2000),
    BLOCKED_CLIENT                     VARCHAR(2000),
    BLOCKED_QUERYID                    BIGINT,
    BLOCKED_PLANID                     BIGINT,
    BLOCKED_DURA_SEC                   BIGINT,
    LOCK_TYPE                          VARCHAR(2000),
    LOCK_DB                            VARCHAR(2000),
    LOCK_TABLE                         VARCHAR(2000),
    LOCK_ROW_NUM                       BIGINT
);
CREATE INDEX IDX_PEV_LONG_LOCKS_HIS_SAMPLE_TIME ON PEV.PEV_LONG_LOCKS_HIS(SAMPLE_TIME);
/********************************************************************
 * VIEW & TABLE PEV.PEV_METRICS
 ********************************************************************/
CREATE FUNCTION PEV.PEV_METRICS(
    OUT CPU_USER_NORMAL_PCT  float4,
    OUT CPU_USER_NICED_PCT   float4,
    OUT CPU_KERNEL_PCT       float4,
    OUT CPU_IDLE_PCT         float4,
    OUT CPU_IO_PCT           float4,
    OUT CPU_MODEL            text,
    OUT CPU_PRO_TYPE         text,   -- none
    OUT CPU_PRO_LOGICAL_CNT  int4,
    OUT CPU_PRO_PHYSICAL_CNT int4,
    OUT CPU_CORE_CNT         int4,
    OUT CPU_ARCH             text,
    OUT CPU_L1D_CACHE_SIZE   int4,
    OUT CPU_L1I_CACHE_SIZE   int4,
    OUT CPU_L2_CACHE_SIZE    int4,
    OUT CPU_L3_CACHE_SIZE    int4,
    OUT MEM_TOTAL_MB         float4,
    OUT MEM_USED_MB          float4,
    OUT MEM_FREE_MB          float4,
    OUT MEM_SWAP_TOTAL_MB    float4,
    OUT MEM_SWAP_USED_MB     float4,
    OUT MEM_SWAP_FREE_MB     float4,
    OUT DISK_TOTAL_MB        float4,
    OUT DISK_USED_MB         float4,
    OUT DISK_FREE_MB         float4,
    OUT DISK_RD_CNT          int8,
    OUT DISK_WT_CNT          int8,
    OUT DISK_RD_KB           float8,
    OUT DISK_WT_KB           float8,
    OUT PRO_TOTAL_CNT        int4,
    OUT PRO_ACTIVE_CNT       int4,
    OUT PRO_SLEEP_CNT        int4,
    OUT PRO_STOPPED_CNT      int4,
    OUT PRO_ZOMBIE_CNT       int4,
    OUT NET_DATA_SEND_KB     float8,
    OUT NET_PACKAGES_SEND    int8,
    OUT NET_ERR_SEND         int8,
    OUT NET_PACKAGES_SDROP   int8,
    OUT NET_DATA_RECEIVE_KB  float8,
    OUT NET_PACKAGES_RECEIVE int8,
    OUT NET_ERR_RECEIVE      int8,
    OUT NET_PACKAGES_RDROP   int8
)
    RETURNS SETOF record
AS 'MODULE_PATHNAME'
LANGUAGE C;
GRANT EXECUTE ON FUNCTION PEV.PEV_METRICS() TO PUBLIC;
CREATE VIEW PEV.PEV_METRICS AS
(
    WITH OS AS
    (
        SELECT *
        FROM PEV.PEV_METRICS()
    ),
    DB AS
    (
        SELECT SUM( NUMBACKENDS ) AS CONN_TOTAL,
               ( SELECT COUNT ( DISTINCT concat(client_addr, client_port) ) FROM PG_STAT_ACTIVITY WHERE STATE IN ( 'active', 'idle in transaction' ) AND BACKEND_TYPE = 'client backend' ) AS CONN_ACTIVE,
               ( SELECT COUNT ( * ) FROM PG_STAT_ACTIVITY WHERE  BACKEND_TYPE = 'client backend' ) AS SESS_BG_TOTAL,
               ( SELECT COUNT ( * ) FROM PG_STAT_ACTIVITY WHERE STATE IN ( 'active', 'idle in transaction' ) AND BACKEND_TYPE = 'client backend' ) AS SESS_BG_ACTIVE,
               SUM ( XACT_COMMIT + XACT_ROLLBACK ) AS TX_TOTAL,
               SUM ( XACT_COMMIT ) AS TX_COMMIT,
               SUM ( XACT_ROLLBACK ) AS TX_ROLLBACK,
               ROUND( SUM ( TEMP_BYTES ) / 1024, 2 ) AS TEMP_KB,
               SUM ( TUP_FETCHED ) AS FETCHS_ROWS,
               SUM ( TUP_INSERTED ) AS INSERT_ROWS,
               SUM ( TUP_UPDATED ) AS UPDATE_ROWS,
               SUM ( TUP_DELETED ) AS DELETE_ROWS,
               ( SELECT ROUND( SUM ( SIZE ) / 1024, 2 ) FROM pg_ls_waldir ( ) ) AS WAL_KB,
               ROUND( SUM ( BLKS_HIT )) AS LOGICAL_RD_CNT,
               ROUND( SUM ( BLKS_READ )) AS PHY_RD_CNT,
               ( SELECT ROUND( SUM ( pg_database_size ( DATNAME ) ) / 1024 / 1024, 2 ) FROM PG_DATABASE ) AS DBSIZE_MB ,
               SUM( CONFLICTS ) AS CONFLICTS_CNT,
               SUM( DEADLOCKS ) AS DEADLOCKS_CNT
        FROM PG_STAT_DATABASE
        WHERE DATNAME NOT IN ( 'template0', 'template1' )
    )

    SELECT 'OS(CPU)' AS METRIC_GROUP,
           '1001' AS METRIC_ID,
           'CPU_USER_NORMAL_PCT' AS METRIC_NAME,
           OS.CPU_USER_NORMAL_PCT :: VARCHAR(200) AS VALUE,
           '%' AS UNITS,
           'Percentage of CPU time spent processing user-mode processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
           '1002' AS METRIC_ID,
           'CPU_USER_NICED_PCT' AS METRIC_NAME,
           OS.CPU_USER_NICED_PCT :: VARCHAR(200) AS VALUE,
           '%' AS UNITS,
           'Percentage of time spent by CPU processing the priority of user-mode scheduling process' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
           '1003' AS METRIC_ID,
           'CPU_KERNEL_PCT' AS METRIC_NAME,
           OS.CPU_KERNEL_PCT :: VARCHAR(200) AS VALUE,
           '%' AS UNITS,
           'Percentage of CPU time spent processing kernel processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
           '1004' AS METRIC_ID,
           'CPU_IDLE_PCT' AS METRIC_NAME,
           OS.CPU_IDLE_PCT :: VARCHAR(200) AS VALUE,
           '%' AS UNITS,
           'Percentage of CPU idle time' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1005' AS METRIC_ID,
            'CPU_IO_PCT' AS METRIC_NAME,
            OS.CPU_IO_PCT :: VARCHAR(200) AS VALUE,
            '%' AS UNITS,
            'Percentage of time spent by CPU processing I/O' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1006' AS METRIC_ID,
            'CPU_MODEL' AS METRIC_NAME,
            OS.CPU_MODEL :: VARCHAR(200) AS VALUE,
            '-' AS UNITS,
            'CPU model name' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1007' AS METRIC_ID,
            'CPU_PRO_LOGICAL_CNT' AS METRIC_NAME,
            OS.CPU_PRO_LOGICAL_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of CPU logical processors' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1008' AS METRIC_ID,
            'CPU_PRO_PHYSICAL_CNT' AS METRIC_NAME,
            OS.CPU_PRO_PHYSICAL_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of CPU physical processors' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1009' AS METRIC_ID,
            'CPU_CORE_CNT' AS METRIC_NAME,
            OS.CPU_CORE_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of CPU cores' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1010' AS METRIC_ID,
            'CPU_ARCH' AS METRIC_NAME,
            OS.CPU_ARCH :: VARCHAR(200) AS VALUE,
            '-' AS UNITS,
            'CPU architecture' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1011' AS METRIC_ID,
            'CPU_L1D_CACHE_SIZE' AS METRIC_NAME,
            OS.CPU_L1D_CACHE_SIZE :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'CPU L1 data cache size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1012' AS METRIC_ID,
            'CPU_L1I_CACHE_SIZE' AS METRIC_NAME,
            OS.CPU_L1I_CACHE_SIZE :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'CPU L1 instruction cache size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1013' AS METRIC_ID,
            'CPU_L2_CACHE_SIZE' AS METRIC_NAME,
            OS.CPU_L2_CACHE_SIZE :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'CPU L2 cache size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(CPU)' AS METRIC_GROUP,
            '1014' AS METRIC_ID,
            'CPU_L3_CACHE_SIZE' AS METRIC_NAME,
            OS.CPU_L3_CACHE_SIZE :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'CPU L3 cache size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1015' AS METRIC_ID,
            'MEM_TOTAL_MB' AS METRIC_NAME,
            OS.MEM_TOTAL_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Total memory capacity size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1016' AS METRIC_ID,
            'MEM_USED_MB' AS METRIC_NAME,
            OS.MEM_USED_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Current memory capacity usage' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1017' AS METRIC_ID,
            'MEM_FREE_MB' AS METRIC_NAME,
            OS.MEM_FREE_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Current memory capacity free size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1018' AS METRIC_ID,
            'MEM_SWAP_TOTAL_MB' AS METRIC_NAME,
            OS.MEM_SWAP_TOTAL_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Swap partition size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1019' AS METRIC_ID,
            'MEM_SWAP_USED_MB' AS METRIC_NAME,
            OS.MEM_SWAP_USED_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Used size of swap partition' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(MEMORY)' AS METRIC_GROUP,
            '1020' AS METRIC_ID,
            'MEM_SWAP_FREE_MB' AS METRIC_NAME,
            OS.MEM_SWAP_FREE_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Free size of swap partition' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1021' AS METRIC_ID,
            'DISK_TOTAL_MB' AS METRIC_NAME,
            OS.DISK_TOTAL_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Total disk capacity' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1022' AS METRIC_ID,
            'DISK_USED_MB' AS METRIC_NAME,
            OS.DISK_USED_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Disk used size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1023' AS METRIC_ID,
            'DISK_FREE_MB' AS METRIC_NAME,
            OS.DISK_FREE_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Disk free size' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1024' AS METRIC_ID,
            'DISK_RD_CNT' AS METRIC_NAME,
            OS.DISK_RD_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of disk reads, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1025' AS METRIC_ID,
            'DISK_WT_CNT' AS METRIC_NAME,
            OS.DISK_WT_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of disk writes, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1026' AS METRIC_ID,
            'DISK_RD_KB' AS METRIC_NAME,
            OS.DISK_RD_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'Disk read data size, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(DISK)' AS METRIC_GROUP,
            '1027' AS METRIC_ID,
            'DISK_WT_KB' AS METRIC_NAME,
            OS.DISK_WT_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'Disk write data size, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(PROCESS)' AS METRIC_GROUP,
            '1028' AS METRIC_ID,
            'PRO_TOTAL_CNT' AS METRIC_NAME,
            OS.PRO_TOTAL_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of current processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(PROCESS)' AS METRIC_GROUP,
            '1029' AS METRIC_ID,
            'PRO_ACTIVE_CNT' AS METRIC_NAME,
            OS.PRO_ACTIVE_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of current active processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(PROCESS)' AS METRIC_GROUP,
            '1030' AS METRIC_ID,
            'PRO_SLEEP_CNT' AS METRIC_NAME,
            OS.PRO_SLEEP_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of current sleep processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(PROCESS)' AS METRIC_GROUP,
            '1031' AS METRIC_ID,
            'PRO_STOPPED_CNT' AS METRIC_NAME,
            OS.PRO_STOPPED_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of current stopped processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(PROCESS)' AS METRIC_GROUP,
            '1032' AS METRIC_ID,
            'PRO_ZOMBIE_CNT' AS METRIC_NAME,
            OS.PRO_ZOMBIE_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of current zombiz processes' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1033' AS METRIC_ID,
            'NET_DATA_SEND_KB' AS METRIC_NAME,
            OS.NET_DATA_SEND_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'Network data transmission size, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1034' AS METRIC_ID,
            'NET_PACKAGES_SEND' AS METRIC_NAME,
            OS.NET_PACKAGES_SEND :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of network packets sent, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1035' AS METRIC_ID,
            'NET_ERR_SEND' AS METRIC_NAME,
            OS.NET_ERR_SEND :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of network data transmission errors, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1036' AS METRIC_ID,
            'NET_PACKAGES_SDROP' AS METRIC_NAME,
            OS.NET_PACKAGES_SDROP :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of packets lost in network data transmission, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1037' AS METRIC_ID,
            'NET_DATA_RECEIVE_KB' AS METRIC_NAME,
            OS.NET_DATA_RECEIVE_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'Network data receive size, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1038' AS METRIC_ID,
            'NET_PACKAGES_RECEIVE' AS METRIC_NAME,
            OS.NET_PACKAGES_RECEIVE :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of network packets receive, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1039' AS METRIC_ID,
            'NET_ERR_RECEIVE' AS METRIC_NAME,
            OS.NET_ERR_RECEIVE :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of network data receive errors, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'OS(NETWORK)' AS METRIC_GROUP,
            '1040' AS METRIC_ID,
            'NET_PACKAGES_RDROP' AS METRIC_NAME,
            OS.NET_PACKAGES_RDROP :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of packets lost in network data receive, ps means per seconed of delta' AS DESP
    FROM OS
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2001' AS METRIC_ID,
            'CONN_TOTAL' AS METRIC_NAME,
            DB.CONN_TOTAL :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total current connections' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2002' AS METRIC_ID,
            'CONN_ACTIVE' AS METRIC_NAME,
            DB.CONN_ACTIVE :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Current active connections' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2003' AS METRIC_ID,
            'SESS_BG_TOTAL' AS METRIC_NAME,
            DB.SESS_BG_TOTAL :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of current background sessions' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2004' AS METRIC_ID,
            'SESS_BG_ACTIVE' AS METRIC_NAME,
            DB.SESS_BG_ACTIVE :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of current background active sessions' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2005' AS METRIC_ID,
            'TX_CNT' AS METRIC_NAME,
            DB.TX_TOTAL :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of transactions since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2006' AS METRIC_ID,
            'TX_COMMIT_CNT' AS METRIC_NAME,
            DB.TX_COMMIT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of transactions submitted since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2007' AS METRIC_ID,
            'TX_ROLLBACK_CNT' AS METRIC_NAME,
            DB.TX_ROLLBACK :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of transactions rollbacked since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2008' AS METRIC_ID,
            'TEMP_KB' AS METRIC_NAME,
            DB.TEMP_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'Total size of temporary space occupation size since the server was started' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2009' AS METRIC_ID,
            'FETCHED_CNT' AS METRIC_NAME,
            DB.FETCHS_ROWS :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of rows scanned since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2010' AS METRIC_ID,
            'INSERT_CNT' AS METRIC_NAME,
            DB.INSERT_ROWS :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of rows inserted since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2011' AS METRIC_ID,
            'UPDATE_CNT' AS METRIC_NAME,
            DB.UPDATE_ROWS :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of rows updated since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2012' AS METRIC_ID,
            'DELETE_CNT' AS METRIC_NAME,
            DB.DELETE_ROWS :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Total number of rows deleted since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2013' AS METRIC_ID,
            'WAL_KB' AS METRIC_NAME,
            DB.WAL_KB :: VARCHAR(200) AS VALUE,
            'KB' AS UNITS,
            'The size of the WAL generated since the server was started, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2014' AS METRIC_ID,
            'LOGICAL_RD_CNT' AS METRIC_NAME,
            DB.LOGICAL_RD_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of logical reads since server startup, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2015' AS METRIC_ID,
            'PHYSICAL_RD_CNT' AS METRIC_NAME,
            DB.PHY_RD_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of physical reads since server startup, ps means per seconed of delta' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2016' AS METRIC_ID,
            'DBSIZE_MB' AS METRIC_NAME,
            DB.DBSIZE_MB :: VARCHAR(200) AS VALUE,
            'MB' AS UNITS,
            'Total size of the current databases' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2017' AS METRIC_ID,
            'CONFLICTS_CNT' AS METRIC_NAME,
            DB.CONFLICTS_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'The number of queries cancelled in this database due to conflicts with recovery since the server was started' AS DESP
    FROM DB
    UNION ALL
    SELECT 'DB' AS METRIC_GROUP,
            '2018' AS METRIC_ID,
            'DEADLOCKS_CNT' AS METRIC_NAME,
            DB.DEADLOCKS_CNT :: VARCHAR(200) AS VALUE,
            'number' AS UNITS,
            'Number of deadlocks since the server was started' AS DESP
    FROM DB
);
GRANT SELECT ON PEV.PEV_METRICS TO PUBLIC;
CREATE TABLE IF NOT EXISTS PEV.PEV_METRICS_HIS
(
    SNAP_ID           BIGINT,
    SAMPLE_TIME       TIMESTAMP,
    METRIC_GROUP      VARCHAR(2000),
    METRIC_ID         INT4,
    METRIC_NAME       VARCHAR(2000),
    VALUE             VARCHAR(2000),
    VALUE_PS          FLOAT8,
    UNITS             VARCHAR(2000),
    DESP              VARCHAR(2000)
);
CREATE INDEX IDX_PEV_METRICS_HISTORY_SNAP_ID ON PEV.PEV_METRICS_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_METRICS_HISTORY_SAMPLE_TIME ON PEV.PEV_METRICS_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_TABLES_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_TABLES_HIS
(
    SNAP_ID                   BIGINT,
    SAMPLE_TIME               TIMESTAMP,
    DBNAME                    VARCHAR(2000),
    TABLE_OID                 OID,
    SCHEMA_NAME               VARCHAR(2000),
    TABLE_NAME                VARCHAR(2000),
    SEQ_SCAN                  BIGINT,
    SEQ_TUP_READ              BIGINT,
    IDX_SCAN                  BIGINT,
    IDX_TUP_FETCH             BIGINT,
    N_TUP_INS                 BIGINT,
    N_TUP_UPD                 BIGINT,
    N_TUP_DEL                 BIGINT,
    N_TUP_HOT_UPD             BIGINT,
    N_LIVE_TUP                BIGINT,
    N_DEAD_TUP                BIGINT,
    N_MOD_SINCE_ANALYZE       BIGINT,
    HEAP_BLKS_READ            BIGINT,
    HEAP_BLKS_HIT             BIGINT,
    IDX_BLKS_READ             BIGINT,
    IDX_BLKS_HIT              BIGINT,
    TOAST_BLKS_READ           BIGINT,
    TOAST_BLKS_HIT            BIGINT,
    TIDX_BLKS_READ            BIGINT,
    TIDX_BLKS_HIT             BIGINT,
    VACUUM_COUNT              BIGINT,
    AUTOVACUUM_COUNT          BIGINT,
    ANALYZE_COUNT             BIGINT,
    AUTOANALYZE_COUNT         BIGINT,
    LAST_VACUUM               TIMESTAMP,
    LAST_AUTOVACUUM           TIMESTAMP,
    LAST_ANALYZE              TIMESTAMP,
    LAST_AUTOANALYZE          TIMESTAMP,
    SEQ_SCAN_DELTA            BIGINT,
    SEQ_TUP_READ_DELTA        BIGINT,
    IDX_SCAN_DELTA            BIGINT,
    IDX_TUP_FETCH_DELTA       BIGINT,
    N_TUP_INS_DELTA           BIGINT,
    N_TUP_UPD_DELTA           BIGINT,
    N_TUP_DEL_DELTA           BIGINT,
    N_TUP_HOT_UPD_DELTA       BIGINT,
    N_LIVE_TUP_DELTA          BIGINT,
    N_DEAD_TUP_DELTA          BIGINT,
    N_MOD_SINCE_ANALYZE_DELTA BIGINT,
    HEAP_BLKS_READ_DELTA      BIGINT,
    HEAP_BLKS_HIT_DELTA       BIGINT,
    IDX_BLKS_READ_DELTA       BIGINT,
    IDX_BLKS_HIT_DELTA        BIGINT,
    TOAST_BLKS_READ_DELTA     BIGINT,
    TOAST_BLKS_HIT_DELTA      BIGINT,
    TIDX_BLKS_READ_DELTA      BIGINT,
    TIDX_BLKS_HIT_DELTA       BIGINT,
    VACUUM_COUNT_DELTA        BIGINT,
    AUTOVACUUM_COUNT_DELTA    BIGINT,
    ANALYZE_COUNT_DELTA       BIGINT,
    AUTOANALYZE_COUNT_DELTA   BIGINT
);
CREATE INDEX IDX_PEV_TABLES_VARIATION_SNAP_ID ON PEV.PEV_TABLES_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_TABLES_VARIATION_SAMPLE_TIME ON PEV.PEV_TABLES_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_INDEXES_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_INDEXES_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    TABLE_OID                OID,
    INDEX_OID                OID,
    SCHEMA_NAME              VARCHAR(2000),
    TABLE_NAME               VARCHAR(2000),
    INDEX_NAME               VARCHAR(2000),
    IDX_SCAN                 BIGINT,
    IDX_TUP_READ             BIGINT,
    IDX_TUP_FETCH            BIGINT,
    IDX_BLKS_READ            BIGINT,
    IDX_BLKS_HIT             BIGINT,
    IDX_SCAN_DELTA           BIGINT,
    IDX_TUP_READ_DELTA       BIGINT,
    IDX_TUP_FETCH_DELTA      BIGINT,
    IDX_BLKS_READ_DELTA      BIGINT,
    IDX_BLKS_HIT_DELTA       BIGINT
);
CREATE INDEX IDX_PEV_INDEXES_VARIATION_SNAP_ID ON PEV.PEV_INDEXES_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_INDEXES_VARIATION_SAMPLE_TIME ON PEV.PEV_INDEXES_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_SEQUENCES_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_SEQUENCES_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    SEQUENCE_OID             OID,
    SCHEMA_NAME              VARCHAR(2000),
    SEQUENCE_NAME            VARCHAR(2000),
    BLKS_READ                BIGINT,
    BLKS_HIT                 BIGINT,
    BLKS_READ_DELTA          BIGINT,
    BLKS_HIT_DELTA           BIGINT
);
CREATE INDEX IDX_PEV_SEQUENCES_VARIATION_SNAP_ID ON PEV.PEV_SEQUENCES_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_SEQUENCES_VARIATION_SAMPLE_TIME ON PEV.PEV_SEQUENCES_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_FUNCTIONS_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_FUNCTIONS_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    FUNCTION_OID             OID,
    SCHEMA_NAME              VARCHAR(2000),
    FUNCTION_NAME            VARCHAR(2000),
    CALLS                    BIGINT,
    TOTAL_TIME_MS            BIGINT,
    SELF_TIME_MS             BIGINT,
    CALLS_DELTA              BIGINT,
    TOTAL_TIME_MS_DELTA      BIGINT,
    SELF_TIME_MS_DELTA       BIGINT
);
CREATE INDEX IDX_PEV_FUNCTIONS_VARIATION_SNAP_ID ON PEV.PEV_FUNCTIONS_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_FUNCTIONS_VARIATION_SAMPLE_TIME ON PEV.PEV_FUNCTIONS_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_DATABASE_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_DATABASE_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    DATABASE_OID             OID,
    DATABASE_NAME            VARCHAR(2000),
    CURRENT_BACKENDS         BIGINT,
    XACT_COMMIT              BIGINT,
    XACT_ROLLBACK            BIGINT,
    BLKS_READ                BIGINT,
    BLKS_HIT                 BIGINT,
    TUP_RETURNED             BIGINT,
    TUP_FETCHED              BIGINT,
    TUP_INSERTED             BIGINT,
    TUP_UPDATED              BIGINT,
    TUP_DELETED              BIGINT,
    CONFLICTS                BIGINT,
    TEMP_FILES               BIGINT,
    TEMP_BYTES               BIGINT,
    DEADLOCKS                BIGINT,
    BLK_READ_TIME_MS         BIGINT,
    BLK_WRITE_TIME_MS        BIGINT,
    CURRENT_BACKENDS_DELTA   BIGINT,
    XACT_COMMIT_DELTA        BIGINT,
    XACT_ROLLBACK_DELTA      BIGINT,
    BLKS_READ_DELTA          BIGINT,
    BLKS_HIT_DELTA           BIGINT,
    TUP_RETURNED_DELTA       BIGINT,
    TUP_FETCHED_DELTA        BIGINT,
    TUP_INSERTED_DELTA       BIGINT,
    TUP_UPDATED_DELTA        BIGINT,
    TUP_DELETED_DELTA        BIGINT,
    CONFLICTS_DELTA          BIGINT,
    TEMP_FILES_DELTA         BIGINT,
    TEMP_BYTES_DELTA         BIGINT,
    DEADLOCKS_DELTA          BIGINT,
    BLK_READ_TIME_MS_DELTA   BIGINT,
    BLK_WRITE_TIME_MS_DELTA  BIGINT
);
CREATE INDEX IDX_PEV_DATABASE_VARIATION_SNAP_ID ON PEV.PEV_DATABASE_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_DATABASE_VARIATION_SAMPLE_TIME ON PEV.PEV_DATABASE_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_BGWRITER_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_BGWRITER_HIS
(
    SNAP_ID                        BIGINT,
    SAMPLE_TIME                    TIMESTAMP,
    CHECKPOINTS_TIMED              BIGINT,
    CHECKPOINTS_REQ                BIGINT,
    CHECKPOINT_WRITE_TIME_MS       BIGINT,
    CHECKPOINT_SYNC_TIME_MS        BIGINT,
    BUFFERS_CHECKPOINT             BIGINT,
    BUFFERS_CLEAN                  BIGINT,
    MAXWRITTEN_CLEAN               BIGINT,
    BUFFERS_BACKEND                BIGINT,
    BUFFERS_BACKEND_FSYNC          BIGINT,
    BUFFERS_ALLOC                  BIGINT,
    CHECKPOINTS_TIMED_DELTA        BIGINT,
    CHECKPOINTS_REQ_DELTA          BIGINT,
    CHECKPOINT_WRITE_TIME_MS_DELTA BIGINT,
    CHECKPOINT_SYNC_TIME_MS_DELTA  BIGINT,
    BUFFERS_CHECKPOINT_DELTA       BIGINT,
    BUFFERS_CLEAN_DELTA            BIGINT,
    MAXWRITTEN_CLEAN_DELTA         BIGINT,
    BUFFERS_BACKEND_DELTA          BIGINT,
    BUFFERS_BACKEND_FSYNC_DELTA    BIGINT,
    BUFFERS_ALLOC_DELTA            BIGINT
);
CREATE INDEX IDX_PEV_BGWRITER_VARIATION_SNAP_ID ON PEV.PEV_BGWRITER_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_BGWRITER_VARIATION_SAMPLE_TIME ON PEV.PEV_BGWRITER_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_ARCHIVER_VARIATION
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_ARCHIVER_HIS
(
    SNAP_ID                  BIGINT,
    SAMPLE_TIME              TIMESTAMP,
    ARCHIVED_COUNT           BIGINT,
    LAST_ARCHIVED_WAL        VARCHAR(2000),
    LAST_ARCHIVED_TIME       TIMESTAMP,
    FAILED_COUNT             BIGINT,
    LAST_FAILED_WAL          VARCHAR(2000),
    LAST_FAILED_TIME         TIMESTAMP,
    ARCHIVED_COUNT_DELTA     BIGINT,
    FAILED_COUNT_DELTA       BIGINT
);
CREATE INDEX IDX_PEV_ARCHIVER_VARIATION_SNAP_ID ON PEV.PEV_ARCHIVER_HIS(SNAP_ID);
CREATE INDEX IDX_PEV_ARCHIVER_VARIATION_SAMPLE_TIME ON PEV.PEV_ARCHIVER_HIS(SAMPLE_TIME);
/********************************************************************
 * TABLE PEV.PEV_SETTING
 ********************************************************************/
CREATE TABLE IF NOT EXISTS PEV.PEV_SETTING
(
    NAME      VARCHAR(2000),
    VALUE     INT NOT NULL,
    UNIT      VARCHAR(2000),
    DESP      VARCHAR(2000)
);
INSERT INTO PEV.PEV_SETTING
    (NAME, VALUE, UNIT, DESP)
VALUES
    (
         'PEV_MAX_SQL',
         10000,
         'NUMBER',
         'Max sql stats info to hold, the value should not be less than 1000'
    ),
    (
         'PEV_MAX_SIZE',
         5120,
         'MB',
         'Maximum data size held by pev module, automatic cleaning when exceeding, the value should not be less than 1024'
    ),
    (
         'PEV_MIN_TIME',
         7,
         'DAY',
         'Minimum data dwell time held by the PEV module, priority is higher than PEV_MAX_SIZE in garbage cleaning, the value should not be less than 1'
    ),
    (
         'PEV_TRACK_UTILITY_SQL',
         0,
         '-',
         'Whether the PEV module tracks utility SQL, Non-0 means yes'
    ),
    (
         'PEV_SQL_TRACK_LEVEL',
         1,
         '-',
         'PEV module track level of SQL statements, 0: no tracking, 1: track top level SQL, 2 track all SQL, including inner nested statements'
    ),
    (
        'PEV_ASH_FREQUENCY',
        30,
        'SECONED',
        'PEV_ACTIVE_SESSION_HIS gather interval, normal value should not be less than 10 when opening, -1 for close'
    ),
    (
        'PEV_METRICS_FREQUENCY',
        60,
        'SECONED',
        'PEV_METRICS_HIS gather interval, normal value should not be less than 10 when opening, -1 for close'
    ),
    (
        'PEV_WAIT_EVENTS_FREQUENCY',
        60,
        'SECONED',
        'PEV_WAIT_EVENTS_HIS gather interval, normal value should not be less than 10 when opening, -1 for close'
    ),
    (
        'PEV_LONG_TRXS_FREQUENCY',
        60,
        'SECONED',
        'PEV_LONG_TRXS_HIS gather interval, normal value should not be less than 10 when opening, -1 for close'
    ),
    (
        'PEV_LONG_LOCKS_FREQUENCY',
        60,
        'SECONED',
        'PEV_LONG_LOCKS_HIS gather interval, normal value should not be less than 10 when opening, -1 for close'
    ),
    (
        'PEV_DATABASE_FREQUENCY',
        600,
        'SECONED',
        'PEV_DATABASE_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_TABLES_FREQUENCY',
        600,
        'SECONED',
        'PEV_TABLES_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_INDEXES_FREQUENCY',
        600,
        'SECONED',
        'PEV_INDEXES_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_SEQUENCES_FREQUENCY',
        600,
        'SECONED',
        'PEV_SEQUENCES_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_FUNCTIONS_FREQUENCY',
        600,
        'SECONED',
        'PEV_FUNCTIONS_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_BGWRITER_FREQUENCY',
        600,
        'SECONED',
        'PEV_BGWRITER_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_ARCHIVER_FREQUENCY',
        600,
        'SECONED',
        'PEV_ARCHIVER_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    ),
    (
        'PEV_SQL_STATS_FREQUENCY',
        600,
        'SECONED',
        'PEV_SQL_STATS_HIS gather interval, normal value should not be less than 60 when opening, -1 for close'
    );
/********************************************************************
 * PRIVILEGES MANAGEMENT
 ********************************************************************/
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA PEV FROM public;
GRANT USAGE ON SCHEMA PEV TO public;
GRANT SELECT ON ALL TABLES IN SCHEMA PEV TO public;
GRANT UPDATE(VALUE) ON PEV.PEV_SETTING TO public;
GRANT USAGE ON SCHEMA pg_catalog TO pev;
GRANT USAGE ON SCHEMA PEV TO pev;
GRANT SELECT ON ALL TABLES IN SCHEMA PEV TO pev;
GRANT SELECT ON ALL TABLES IN SCHEMA pg_catalog TO pev;
GRANT UPDATE(VALUE) ON PEV.PEV_SETTING TO pev;
GRANT EXECUTE ON FUNCTION pg_ls_waldir() TO pev;


